{\rtf1\ansi\ansicpg1252\cocoartf2761
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
{\*\listtable{\list\listtemplateid1\listhybrid{\listlevel\levelnfc0\levelnfcn0\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{decimal\}.}{\leveltext\leveltemplateid1\'02\'00.;}{\levelnumbers\'01;}\fi-360\li720\lin720 }{\listname ;}\listid1}}
{\*\listoverridetable{\listoverride\listid1\listoverridecount0\ls1}}
\margl1440\margr1440\vieww28300\viewh14460\viewkind0
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\pardirnatural\partightenfactor0
\ls1\ilvl0
\f0\fs24 \cf0 {\listtext	1.	}CREATE SCHEMA IF NOT EXISTS `alkewallet` ;\
{\listtext	2.	}\
{\listtext	3.	}CREATE TABLE IF NOT EXISTS `alkewallet`.`users` (\
{\listtext	4.	}  `iduser` INT NOT NULL AUTO_INCREMENT,\
{\listtext	5.	}  `name` VARCHAR(45) NOT NULL,\
{\listtext	6.	}  `email` VARCHAR(45) NOT NULL,\
{\listtext	7.	}  `password` VARCHAR(45) NOT NULL,\
{\listtext	8.	}  `balance` VARCHAR(45) NOT NULL,\
{\listtext	9.	}  PRIMARY KEY (`iduser`));\
{\listtext	10.	}\
{\listtext	11.	}CREATE TABLE IF NOT EXISTS `alkewallet`.`currencies` (\
{\listtext	12.	}  `idcurrencies` INT NOT NULL AUTO_INCREMENT,\
{\listtext	13.	}  `name` VARCHAR(45) NOT NULL,\
{\listtext	14.	}  `symbol` VARCHAR(45) NOT NULL,\
{\listtext	15.	}  PRIMARY KEY (`idcurrencies`));\
{\listtext	16.	}   \
{\listtext	17.	}CREATE TABLE IF NOT EXISTS `alkewallet`.`transactions` (\
{\listtext	18.	}  `idtransactions` INT NOT NULL AUTO_INCREMENT,\
{\listtext	19.	}  `sender_iduser` INT NULL,\
{\listtext	20.	}  `receiver_iduser` INT NULL,\
{\listtext	21.	}  `amount` INT NOT NULL,\
{\listtext	22.	}  `transaction_date` DATE NOT NULL,\
{\listtext	23.	}  `idcurrencies` INT NOT NULL,\
{\listtext	24.	}  PRIMARY KEY (`idtransactions`));\
{\listtext	25.	}   \
{\listtext	26.	}ALTER TABLE `alkewallet`.`transactions` \
{\listtext	27.	}CHANGE COLUMN `idcurrencies` `idcurrencies` INT NULL ,\
{\listtext	28.	}ADD INDEX `fk_transactions_1_idx` (`sender_iduser` ASC) VISIBLE,\
{\listtext	29.	}ADD INDEX `fk_transactions_2_idx` (`receiver_iduser` ASC) VISIBLE,\
{\listtext	30.	}ADD INDEX `fk_transactions_3_idx` (`idcurrencies` ASC) VISIBLE;\
{\listtext	31.	};\
{\listtext	32.	}ALTER TABLE `alkewallet`.`transactions` \
{\listtext	33.	}ADD CONSTRAINT `fk_transactions_1`\
{\listtext	34.	}  FOREIGN KEY (`sender_iduser`)\
{\listtext	35.	}  REFERENCES `alkewallet`.`users` (`iduser`)\
{\listtext	36.	}  ON DELETE SET NULL\
{\listtext	37.	}  ON UPDATE NO ACTION,\
{\listtext	38.	}ADD CONSTRAINT `fk_transactions_2`\
{\listtext	39.	}  FOREIGN KEY (`receiver_iduser`)\
{\listtext	40.	}  REFERENCES `alkewallet`.`users` (`iduser`)\
{\listtext	41.	}  ON DELETE SET NULL\
{\listtext	42.	}  ON UPDATE NO ACTION,\
{\listtext	43.	}ADD CONSTRAINT `fk_transactions_3`\
{\listtext	44.	}  FOREIGN KEY (`idcurrencies`)\
{\listtext	45.	}  REFERENCES `alkewallet`.`currencies` (`idcurrencies`)\
{\listtext	46.	}  ON DELETE SET NULL\
{\listtext	47.	}  ON UPDATE NO ACTION;\
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\pardirnatural\partightenfactor0
\ls1\ilvl0\cf0 {\listtext	48.	}		\
{\listtext	49.	}INSERT INTO `alkewallet`.`users` (`iduser`, `name`, `email`, `password`, `balance`) VALUES ('1', 'Felipe', 'Felipe30@gmail.com', '123456', '1000000');\
{\listtext	50.	}\
{\listtext	51.	}INSERT INTO `alkewallet`.`users` (`iduser`, `name`, `email`, `password`, `balance`) VALUES ('2', 'Juliane', 'Juliane30@gmail.com', '123456', '2000000');\
{\listtext	52.	}INSERT INTO `alkewallet`.`users` (`iduser`, `name`, `email`, `password`, `balance`) VALUES ('3', 'Victor', 'Victor@gmail.com', '123456', '3000000');\
{\listtext	53.	}INSERT INTO `alkewallet`.`users` (`iduser`, `name`, `email`, `password`, `balance`) VALUES ('4', 'Nelly', 'Nelly@gmail.com', '123456', '4000000');\
{\listtext	54.	}INSERT INTO `alkewallet`.`users` (`iduser`, `name`, `email`, `password`, `balance`) VALUES ('5', 'Javiera', 'Javiera@gmail.com', '123456', '5000000');\
{\listtext	55.	}  \
{\listtext	56.	}INSERT INTO `alkewallet`.`currencies` (`idcurrencies`, `name`, `symbol`) VALUES ('1', 'chilean Peso', '$');\
{\listtext	57.	}INSERT INTO `alkewallet`.`currencies` (`idcurrencies`, `name`, `symbol`) VALUES ('2', 'American Dollar', '$');\
{\listtext	58.	}  \
{\listtext	59.	}INSERT INTO `alkewallet`.`transactions` (`idtransactions`, `sender_iduser`, `receiver_iduser`, `amount`, `transaction_date`, `idcurrencies`) VALUES ('1', '5', '2', '200000', '2024-03-23', '1');\
{\listtext	60.	}INSERT INTO `alkewallet`.`transactions` (`idtransactions`, `sender_iduser`, `receiver_iduser`, `amount`, `transaction_date`, `idcurrencies`) VALUES ('2', '2', '1', '1000', '2024-03-20', '2');\
{\listtext	61.	}INSERT INTO `alkewallet`.`transactions` (`idtransactions`, `sender_iduser`, `receiver_iduser`, `amount`, `transaction_date`, `idcurrencies`) VALUES ('3', '3', '4', '500000', '2024-03-19', '1');\
{\listtext	62.	}INSERT INTO `alkewallet`.`transactions` (`idtransactions`, `sender_iduser`, `receiver_iduser`, `amount`, `transaction_date`, `idcurrencies`) VALUES ('4', '2', '4', '100000', '2024-03-24', '1');\
{\listtext	63.	}INSERT INTO `alkewallet`.`transactions` (`idtransactions`, `sender_iduser`, `receiver_iduser`, `amount`, `transaction_date`, `idcurrencies`) VALUES ('5', '1', '3', '200', '2024-03-24', '2');\
{\listtext	64.	}   \
{\listtext	65.	}  \
{\listtext	66.	}\'97 Mi comentarios.\
{\listtext	67.	}ALTER TABLE `alkewallet`.`currencies` \
{\listtext	68.	}CHANGE COLUMN `idcurrencies` `idmonedas` INT NOT NULL AUTO_INCREMENT , RENAME TO  `alkewallet`.`monedas` ;\
{\listtext	69.	}  \
{\listtext	70.	}   -- Consulta de Transacion. \
{\listtext	71.	}    SELECT \
{\listtext	72.	}    u.name, \
{\listtext	73.	}    IFNULL(m.name, 'Ninguna') AS moneda_elegida\
{\listtext	74.	}FROM \
{\listtext	75.	}    users u\
{\listtext	76.	}LEFT JOIN \
{\listtext	77.	}    transactions t ON u.iduser = t.sender_iduser\
{\listtext	78.	}LEFT JOIN \
{\listtext	79.	}    monedas m ON t.idcurrencies = m.idmonedas\
{\listtext	80.	}WHERE \
{\listtext	81.	}    u.iduser = 3 ;\
{\listtext	82.	}  \
{\listtext	83.	} -- Consulta para obtener todas las transacciones registradas\
{\listtext	84.	}SELECT * FROM transactions;\
{\listtext	85.	}\
{\listtext	86.	} --Consulta para obtener todas las transacciones realizadas por un\
{\listtext	87.	}usuario espec\'edfico         \
{\listtext	88.	}SELECT * FROM transactions WHERE sender_iduser = 2 ;\
{\listtext	89.	} \
{\listtext	90.	}  \'97 Sentencia DML para modificar el campo correo electr\'f3nico de un\
{\listtext	91.	}usuario espec\'edfico\
{\listtext	92.	}     UPDATE `alkewallet`.`users` SET `email` = 'Felipe@gmail.com' WHERE (`iduser` = '1');\
{\listtext	93.	}   \
{\listtext	94.	}-- Sentencia para eliminar los datos de una transacci\'f3n (eliminado de la fila completa)\
{\listtext	95.	}DELETE FROM transactions where idtransactions = 1 ;\
}